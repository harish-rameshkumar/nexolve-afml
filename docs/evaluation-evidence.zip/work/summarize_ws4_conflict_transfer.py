"""Audit paired transfer data and recompute scores from generated tokens."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import re
from statistics import mean
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
FOLDER = ROOT / "outputs/WS4-conflict-transfer"
PLAN = FOLDER / "protocol.json"
NAMES = [f"{a}_s{s}" for a in "TDP" for s in (0, 1)]
STYLES = ("original", "negated", "allowed")
LAYOUTS = ("sentences", "records")


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def verify(evaluation):
    for key, cases in evaluation.items():
        base = evaluation[f"{key.split('/')[0]}/original/sentences"]
        assert len(cases) == 48
        for a, b in zip(cases, base, strict=True):
            for field in ("pair", "target", "foil", "directive_first"):
                assert a[field] == b[field]
            assert re.findall(r"\d+", a["prompt"]) == re.findall(r"\d+", b["prompt"])
        assert len({tuple(sorted((a["prompt"], b["prompt"])))
                    for a, b in zip(cases[::2], cases[1::2])}) == 24


def recount(rows, values):
    sequences = [r["generated_ids"] for r in values["outputs"]]
    assert len(sequences) == len(rows) == values["n"]
    first = [seq[:1] == [row["target"]] for row, seq in zip(rows, sequences)]
    exact = [seq == [row["target"], 5] for row, seq in zip(rows, sequences)]
    metrics = {"first_correct": sum(first), "exact_and_end": sum(exact),
               "first_pairs": sum(a and b for a, b in zip(first[::2], first[1::2])),
               "strict_pairs": sum(a and b for a, b in zip(exact[::2], exact[1::2])),
               "stopped": sum(5 in seq for seq in sequences),
               "foil_first": sum(seq[:1] == [row["foil"]] for row, seq in zip(rows, sequences))}
    assert all(metrics[k] == values[k] for k in metrics)
    metrics["wrong_first"] = len(rows) - metrics["first_correct"]
    if rows[0].get("pair") is not None:
        for label, first_position in (("directive_before", True), ("directive_after", False)):
            indices = [i for i in range(0, len(rows), 2) if rows[i]["directive_first"] == first_position]
            metrics[label] = sum(exact[i] and exact[i+1] for i in indices)
    return metrics


def main():
    protocol = read(PLAN)
    verify(protocol["evaluation"])
    protocol_hash = sha256(PLAN.read_bytes()).hexdigest()
    results = {}
    for name in NAMES:
        run = read(FOLDER / f"{name}.json")
        assert run["complete"] and run["protocol_sha256"] == protocol_hash and run["name"] == name
        assert [row["tokens"] for row in run["rows"]] == [s*16 for s in protocol["steps"]]
        results[name] = {}
        for row in run["rows"]:
            assert row["anchor_verified"]
            results[name][row["tokens"]] = {key: recount(cases, row["scores"][key])
                                           for key, cases in protocol["evaluation"].items()}
    for budget in (192, 288, 768):
        print("Budget", budget)
        for name, series in results.items():
            point = series[budget]
            print(name, {k: tuple(point[k][m] for m in ("strict_pairs", "first_pairs", "stopped", "foil_first"))
                         for k in point if k.startswith("conflict")})
        for condition in ("agree2", "conflict2"):
            print(condition, "mean correct pairs of 24 across six runs",
                  {f"{w}/{f}": round(mean(r[budget][f"{condition}/{w}/{f}"]["strict_pairs"] for r in results.values()), 2)
                   for w in STYLES for f in LAYOUTS})
    summary = FOLDER / "summary.json"
    summary.write_text(json.dumps({"protocol_sha256": protocol_hash, "results": results}, indent=2)+"\n",
                       encoding="utf-8")
    dependencies = ["ws4_conflict_transfer.py", "summarize_ws4_conflict_transfer.py",
                    "ws4_instruction_conflict_final.py", "ws4_retrieval_pilot.py", "ws4_exploratory.py",
                    "evaluate_ws4_final.py"]
    old = ROOT / "outputs/WS4-instruction-conflict-dense"
    files = [PLAN, summary, *(FOLDER / f"{name}.json" for name in NAMES),
             old / "protocol.json", *(old / f"final-{name}.json" for name in NAMES),
             *(ROOT / "work" / name for name in dependencies)]
    target = ROOT / "outputs/WS4-conflict-transfer-evidence.zip"
    with ZipFile(target, "w", ZIP_DEFLATED) as bundle:
        for path in files:
            bundle.write(path, path.relative_to(ROOT).as_posix())
    with ZipFile(target) as bundle:
        assert bundle.testzip() is None and len(bundle.namelist()) == len(files)


if __name__ == "__main__":
    main()
