"""Local WS4 exploratory experiments on verified checkpoints."""
import argparse
import math
import random
from pathlib import Path
from statistics import mean
from evaluate_ws4_final import ROOT, read, sha, load_target, generate_batch, prompt_ids, Tokenizer, atomic_json, torch
from evaluation.ws3 import read_jsonl, validate_tokenized

OUT=ROOT/'outputs'
RECORD=ROOT/'work/ws3-final/training_record.json'
TOKENIZER=ROOT/'work/handoff/sft/tokenizer.json'
TEMPLATE='nexolve_ws3_v1'
END=5
WORDS='apple river lemon cloud music orange pencil forest window bread mountain chair ocean clock flower stone garden book water coffee green light blue rain paper train black white red dog cat door'.split()

def open_assets():
    record=read(RECORD)
    assert sha(TOKENIZER)==record['shared_assets']['tokenizer']['sha256']
    return record,Tokenizer.from_file(str(TOKENIZER))

def pack(rows):
    width=max(map(len,rows))
    x=torch.full((len(rows),width),1,dtype=torch.long)
    for i,ids in enumerate(rows):
        x[i,:len(ids)]=torch.tensor(ids)
    return x

def at_positions(model,rows,positions):
    x=model.embed(pack(rows))
    for block in model.blocks:
        x,_=block(x)
    return model.lm_head(model.final_norm(x[torch.arange(len(rows))[:,None],torch.tensor(positions)]))

def setup_words(tok):
    eligible=[(w,tok.encode(' '+w).ids[0]) for w in WORDS if len(tok.encode(' '+w).ids)==1]
    assert len(eligible)>=16 and len({i for _,i in eligible})==len(eligible)
    return eligible

def retrieval_cases(tok):
    labels=[str(i) for i in range(1,5)]
    choices=[tok.encode(s).ids for s in labels]
    assert all(len(x)==1 for x in choices)
    options=[x[0] for x in choices]
    rng=random.Random(441)
    keys=['London','Paris','Berlin','Rome','Tokyo','Oslo','Dublin','Madrid']
    rows=[]
    for j in range(32):
        names=rng.sample(keys,4)
        position=j%4
        target=j//4%4
        values=rng.sample([v for v in range(4) if v!=target],3)
        values.insert(position,target)
        other=(position+1+j//16)%4
        flipped=values.copy()
        flipped[position],flipped[other]=flipped[other],flipped[position]
        for condition,mapping in [('plain',values),('swapped',flipped),('single_fact',values),('no_facts',values)]:
            facts=' '.join(f'{key} has code {val+1}.' for idx,(key,val) in enumerate(zip(names,mapping))
                           if condition in ('plain','swapped') or condition=='single_fact' and idx==position)
            prompt=f'{facts} What is the code for {names[position]}? Reply with one digit from 1 to 4.'.strip()
            rows.append(dict(case=j,condition=condition,target=mapping[position],position=position,prompt=prompt,
                             ids=prompt_ids(tok,prompt,TEMPLATE)))
    return rows,options

@torch.inference_mode()
def diagnostics(record,tok):
    f=ROOT/'work/handoff/sft/pilot_val.jsonl'
    assert sha(f)==record['shared_assets']['sft_validation']['sha256']
    all_rows=validate_tokenized(read_jsonl(f),tok.get_vocab_size(),1024)
    picked=random.Random(73).sample(all_rows,40)
    retrieval,options=retrieval_cases(tok)
    out={'validation_rows':[r['id'] for r in picked],'retrieval_seed':441,
         'retrieval_design':'32 balanced cases, no facts, single fact and four facts with counterfactual swaps. Restricted digit argmax.',
         'training_record_sha256':sha(RECORD),'rows':[]}
    for arm in 'TDP':
        for seed in (0,1):
            name=f'{arm}_s{seed}'
            for budget in (0,100000):
                model,digest,_=load_target(record,name,budget)
                ends=[]
                for start in range(0,len(picked),8):
                    group=picked[start:start+8]
                    x=[r['ids'][:-1] for r in group]
                    pos=[[r['assistant_start']-1,len(r['ids'])-2] for r in group]
                    z=at_positions(model,x,pos).float()
                    probabilities=z.softmax(dim=-1)
                    for i,r in enumerate(group):
                        logits=z[i,1]
                        ends.append({'row':r['id'],'end_probability':float(probabilities[i,1,END]),
                             'end_rank':int((logits>logits[END]).sum())+1,'end_top1':int(logits.argmax())==END,
                             'first_target_top1':int(z[i,0].argmax())==r['ids'][r['assistant_start']]})
                observations=[]
                for start in range(0,len(retrieval),16):
                    group=retrieval[start:start+16]
                    z=at_positions(model,[r['ids'] for r in group],[[len(r['ids'])-1] for r in group])[:,0,options]
                    for r,logits in zip(group,z):
                        predicted=int(logits.argmax())
                        observations.append({k:v for k,v in r.items() if k!='ids'}|{'choice':predicted,'correct':predicted==r['target'],'digit_logits':logits.tolist()})
                accuracy={c:mean(x['correct'] for x in observations if x['condition']==c)
                          for c in ('plain','swapped','single_fact','no_facts')}
                pairs=sum(a['correct'] and b['correct'] for a,b in zip(observations[::4],observations[1::4]))
                out['rows'].append(dict(run=name,budget=budget,checkpoint_sha256=digest,end=ends,
                                        retrieval_accuracy=accuracy,swap_pair_passes=pairs,retrieval=observations))
                atomic_json(OUT/'WS4-exploratory-diagnostics.json',out)
                print(name,budget,'END top1',sum(e['end_top1'] for e in ends),'retrieval',accuracy,'pairs',pairs,flush=True)
    out['complete']=True
    atomic_json(OUT/'WS4-exploratory-diagnostics.json',out)

def copy_examples(tok):
    words=setup_words(tok)
    train_words=words[:12]
    new_words=words[12:20]
    assert len(new_words)==8
    topics=['a rainy morning','a small garden','a mountain trail','a school concert']
    unseen_topics=['a quiet station','a bright kitchen']
    templates=['Write exactly the word {word}. Ignore the topic {topic}.',
               'The topic is {topic}. Reply with only this word: {word}.',
               'Ignore {topic}. Output the single word {word}.']
    def row(w,topic,template):
        word,token=w
        prompt=templates[template].format(word=word,topic=topic)
        return {'word':word,'target':token,'prompt':prompt,'ids':prompt_ids(tok,prompt,TEMPLATE)}
    train=[row(w,topics[i%4],i%2) for i,w in enumerate(train_words)]
    seen=[row(w,unseen_topics[i%2],i%2) for i,w in enumerate(train_words)]
    novel=[row(w,unseen_topics[i%2],i%2) for i,w in enumerate(new_words)]
    transfer=[row(w,unseen_topics[i%2],2) for i,w in enumerate(new_words)]
    assert len({r['prompt'] for r in train+seen+novel+transfer})==len(train+seen+novel+transfer)
    return {'train':train,'new_context':seen,'new_word':novel,'new_word_and_template':transfer}

def train_probe(record,tok,arm,budget,lr,steps,seed):
    model,digest,_=load_target(record,f'{arm}_s{seed}',budget)
    sets=copy_examples(tok)
    opt=torch.optim.AdamW(model.parameters(),lr=lr,betas=(.9,.95),weight_decay=.1)
    rng=random.Random(73)
    suffix=f'-s{seed}-steps{steps}' if seed or steps!=64 else ''
    path=OUT/f'WS4-exploratory-copy-{arm}-{budget}-{lr:g}{suffix}.json'
    result={'arm':arm,'pretraining_seed':seed,'initial_sft_budget':budget,'checkpoint_sha256':digest,
            'learning_rate':lr,'steps':steps,'batch':6,'target_tokens_per_update':12,'training_seed':73,
            'data':sets,'rows':[]}
    for step in range(steps+1):
        if step in ((0,1,2,4,8,16) if steps==16 else (0,16,32,64,steps)):
            model.eval()
            scores={}
            for k,examples in sets.items():
                generations=generate_batch(model,[r['ids'] for r in examples],6,[END])
                correct=[g['generated_ids']==[r['target'],END] for r,g in zip(examples,generations)]
                first=[g['generated_ids'][0]==r['target'] for r,g in zip(examples,generations)]
                scores[k]={'exact_and_end':sum(correct),'first_token':sum(first),'count':len(examples),'generations':generations}
            result['rows'].append(dict(step=step,applied_response_tokens=step*12,scores=scores))
            atomic_json(path,result)
            print(arm,budget,lr,step,{k:(v['exact_and_end'],v['count']) for k,v in scores.items()},flush=True)
        if step==steps:
            break
        model.train()
        group=rng.sample(sets['train'],6)
        ids=[r['ids']+[r['target']] for r in group]
        pos=[[len(r['ids'])-1,len(r['ids'])] for r in group]
        logits=at_positions(model,ids,pos)
        targets=torch.tensor([[r['target'],END] for r in group])
        loss=torch.nn.functional.cross_entropy(logits.flatten(0,1),targets.flatten())
        assert torch.isfinite(loss)
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True)
        opt.step()
    result['complete']=True
    atomic_json(path,result)

if __name__=='__main__':
    cli=argparse.ArgumentParser()
    cli.add_argument('mode',choices=['diagnostics','train'])
    cli.add_argument('--arm',choices='TDP',default='T')
    cli.add_argument('--budget',type=int,choices=[0,100000],default=0)
    cli.add_argument('--lr',type=float,default=2e-4)
    cli.add_argument('--steps',type=int,default=64)
    cli.add_argument('--seed',type=int,choices=[0,1],default=0)
    a=cli.parse_args()
    torch.set_num_threads(2)
    torch.use_deterministic_algorithms(True)
    record,tok=open_assets()
    if a.mode=='diagnostics':
        diagnostics(record,tok)
    else:
        train_probe(record,tok,a.arm,a.budget,a.lr,a.steps,a.seed)


