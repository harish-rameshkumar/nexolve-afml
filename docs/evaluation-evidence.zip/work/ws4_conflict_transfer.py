"""Frozen paired wording and demonstration-format test of the original conflict recipe."""
import argparse
import random
import re
from pathlib import Path

from ws4_instruction_conflict_final import (
    PROTOCOL as ORIGINAL, OUT, END, TEMPLATE, at_positions, atomic_json,
    load_target, open_assets, prompt_ids, read, score, sha, torch, cases,
)

FOLDER = OUT / "WS4-conflict-transfer"
PLAN = FOLDER / "protocol.json"
STEPS = (12, 18, 48)
STYLES = ("original", "negated", "allowed")
FORMATS = ("sentences", "records")
CONDITIONS = ("agree2", "conflict2")
RULE = re.compile(r"use (\d) and ignore (\d)|ignore (\d) and use (\d)")
ITEM = re.compile(r"For item (\w+), (.*?)\. Answer: (\d)\.")


def freeze():
    assert not PLAN.exists()
    _, tok = open_assets()
    old = read(ORIGINAL)
    source = cases(tok, 24, 91355, "final")
    selected = {}
    for condition in CONDITIONS:
        for style in STYLES:
            for layout in FORMATS:
                rows = []
                for row in source[condition]:
                    original = row["prompt"]
                    start = original.index("For the ")
                    end = original.index(".", start)
                    clause = original[start:end]
                    rule = RULE.search(clause)
                    yes, no = rule.groups()[:2] if rule[1] else rule.groups()[:1:-1]
                    assert yes and no
                    if style == "negated":
                        clauses = (f"reply only with {yes}", f"do not answer {no}")
                    elif style == "allowed":
                        clauses = (f"the allowed digit is {yes}", f"the forbidden digit is {no}")
                    if style != "original":
                        ordered = clauses if rule[1] else clauses[::-1]
                        clause = "For the final item, " + " and ".join(ordered)
                    prompt = original[:start] + clause + original[end:]
                    if layout == "records":
                        prompt, n = ITEM.subn(r"[item=\1 | rule=\2 | answer=\3]", prompt)
                        assert n == 2
                    rows.append({**row, "prompt": prompt, "ids": prompt_ids(tok, prompt, TEMPLATE)})
                selected[f"{condition}/{style}/{layout}"] = rows
    train = {r["prompt"] for rows in old["training"].values() for r in rows}
    previous = {r["prompt"] for rows in old["evaluation"].values() for r in rows}
    assert not (train | previous).intersection(r["prompt"] for rows in selected.values() for r in rows)
    atomic_json(PLAN, {"source_sha256": sha(ORIGINAL), "script_sha256": sha(Path(__file__)),
        "steps": list(STEPS), "evaluation": selected,
        "metrics": "Strict exact-answer-and-END pairs, correct first-answer pairs, stop rates and foil errors. Compare wording and example layout separately and jointly, using same cases. Compare both seeds at 192, 288 and 768 exposures. No interpolation or new tokens-to-threshold claim."})
    print(sha(PLAN))


def run(arm, seed):
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    record, _ = open_assets()
    plan = read(PLAN)
    assert plan["source_sha256"] == sha(ORIGINAL) and plan["script_sha256"] == sha(Path(__file__))
    old = read(ORIGINAL)
    name = f"{arm}_s{seed}"
    prior = read(ORIGINAL.parent / f"final-{name}.json")
    model, parent, actual = load_target(record, name, 0)
    assert actual == 0 and prior["parent_sha256"] == parent
    opt = torch.optim.AdamW(model.parameters(), lr=old["learning_rate"], betas=(.9,.95), weight_decay=.1)
    training = old["training"]
    rng = random.Random(7816)
    out = {"name": name, "parent_sha256": parent, "protocol_sha256": sha(PLAN), "rows": [], "complete": False}
    path = FOLDER / f"{name}.json"
    for step in range(STEPS[-1]+1):
        if step in STEPS:
            anchor = {key: old["evaluation"][key][:16] for key in CONDITIONS}
            replay = score(model, anchor)
            expected = next(row for row in prior["rows"] if row["step"] == step)["scores"]
            assert all(replay[key]["outputs"] == expected[key]["outputs"][:16] for key in anchor)
            values = score(model, plan["evaluation"])
            for key, v in values.items():
                v["foil_first"] = sum(g["generated_ids"][:1] == [r["foil"]]
                                      for g, r in zip(v["outputs"], plan["evaluation"][key]))
            out["rows"].append({"tokens": step*16, "scores": values, "anchor_verified": True})
            atomic_json(path, out)
            print(name, step*16, {k:v["strict_pairs"] for k,v in values.items()}, flush=True)
        if step == STEPS[-1]:
            break
        model.train()
        batch = [rng.choice(training[k]) for k in (*training, "clean", "conflict2", "conflict6")]
        rng.shuffle(batch)
        logits = at_positions(model, [r["ids"]+[r["target"]] for r in batch],
                              [[len(r["ids"])-1, len(r["ids"])] for r in batch])
        y = torch.tensor([[r["target"],END] for r in batch])
        loss = torch.nn.functional.cross_entropy(logits.flatten(0,1), y.flatten())
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True)
        opt.step()
    out["complete"] = True
    atomic_json(path, out)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--freeze", action="store_true")
    parser.add_argument("--arm", choices="TDP")
    parser.add_argument("--seed", type=int, choices=(0,1))
    args = parser.parse_args()
    FOLDER.mkdir(exist_ok=True)
    if args.freeze:
        freeze()
    else:
        run(args.arm, args.seed)

