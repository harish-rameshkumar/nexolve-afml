"""Recompute instruction-conflict pair scores and evaluate the frozen criterion."""
import json
import re
from pathlib import Path
from hashlib import sha256

ROOT = Path(__file__).resolve().parents[1]
OUTPUTS = ROOT / "outputs"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def verify(run, cases):
    assert run["complete"]
    assert all(r["tokens"] == r["step"] * 16 for r in run["rows"])
    for checkpoint in run["rows"]:
        for condition, examples in cases.items():
            scores = checkpoint["scores"][condition]
            generated = [item["generated_ids"] for item in scores["outputs"]]
            assert len(generated) == len(examples) == scores["n"]
            assert all(a["pair"] == b["pair"] and a["target"] != b["target"]
                       for a, b in zip(examples[::2], examples[1::2]))
            exact = [seq == [example["target"], 5] for seq, example in zip(generated, examples)]
            assert scores["exact_and_end"] == sum(exact)
            assert scores["strict_pairs"] == sum(a and b for a, b in zip(exact[::2], exact[1::2]))
            assert scores["stopped"] == sum(5 in seq for seq in generated)
            assert scores["foil_first"] == sum(seq[:1] == [row["foil"]] for seq, row in zip(generated, examples))
    return {r["tokens"]: {k: v["strict_pairs"]/(v["n"]//2) for k, v in r["scores"].items()}
            for r in run["rows"]}


def sustained(curve, key, target):
    points = list(curve)
    return next((budget for i, budget in enumerate(points)
                 if all(curve[b][key] >= target for b in points[i:])), None)


def pilot_result(path):
    run = read(path)
    curve = verify(run, run["evaluation"])
    print(path.parent.name)
    for row in run["rows"]:
        print(row["tokens"], {k: (v["strict_pairs"], v["n"]//2, v["foil_first"])
                               for k, v in row["scores"].items()})
    eligible = [n for n in (6, 2) if any(
        .50 <= v[f"conflict{n}"] <= .85 and v[f"agree{n}"]-v[f"conflict{n}"] >= .15
        and v["clean"] >= .75 for v in curve.values())]
    print("Eligible strengths:", eligible)


def final_result(folder):
    p = folder / "protocol.json"
    protocol = read(p)
    digest = sha256(p.read_bytes()).hexdigest()
    n = protocol["strength"]
    key = f"conflict{n}"
    agree = f"agree{n}"
    cases = protocol["evaluation"]
    assert sha256((ROOT / "work/ws4_instruction_conflict_final.py").read_bytes()).hexdigest() == protocol["script_sha256"]
    for a, b in zip(cases[agree], cases[key], strict=True):
        assert a["target"] == b["target"] and len(a["ids"]) == len(b["ids"])
    for a, b in zip(cases[key][::2], cases[key][1::2]):
        assert re.findall(r"\d+", a["prompt"]) == re.findall(r"\d+", b["prompt"])
    for a, b in zip(cases[key], cases["alternate_conflict"]):
        assert a["target"] == b["target"] and a["foil"] == b["foil"]
        assert a["prompt"] == b["prompt"].replace("select ", "use ").replace("discard ", "ignore ")
    curves = {}
    thresholds = {}
    parent_hashes = set()
    error_counts = {}
    for seed in (0, 1):
        for arm in "TDP":
            name = f"{arm}_s{seed}"
            run = read(folder / f"final-{name}.json")
            assert run["protocol_sha256"] == digest and run["script_sha256"] == protocol["script_sha256"]
            assert (run["arm"], run["seed"], run["stage"]) == (arm, seed, "final")
            assert run["parent_sha256"] not in parent_hashes
            parent_hashes.add(run["parent_sha256"])
            curve = verify(run, cases)
            assert list(curve) == protocol["budgets"]
            curves[name] = curve
            thresholds[name] = sustained(curve, key, protocol["quality_target"])
            error_counts[name] = {r["tokens"]: {k: {m: v[m] for m in ("n", "stopped", "foil_first")}
                                               for k, v in r["scores"].items()} for r in run["rows"]}
            print(name, "target", thresholds[name], "curve", curve)
    comparisons = {}
    for seed in (0, 1):
        dname = f"D_s{seed}"
        dt = thresholds[dname]
        for comparator in "TP":
            name = f"{comparator}_s{seed}"
            threshold = thresholds[name]
            bound = threshold if threshold is not None else protocol["budgets"][-1]
            saving = 1-dt/bound if dt is not None and bound else None
            gap = None
            control_pass = False
            if dt is not None:
                d = curves[dname][dt]
                c = curves[name][dt]
                gap = (c[agree]-c[key]) - (d[agree]-d[key])
                control_pass = min(d["clean"], d[agree], c["clean"], c[agree]) >= .75
            comparisons[name] = {"token_saving_at_least": saving, "conflict_penalty_reduction": gap,
                "controls_pass": control_pass,
                "passes": saving is not None and saving >= protocol["minimum_token_saving"]
                    and gap >= protocol["minimum_conflict_cost_reduction"] and control_pass}
    result = {"protocol_sha256": digest, "curves": curves, "thresholds": thresholds,
              "comparisons": comparisons, "criterion_met": all(c["passes"] for c in comparisons.values()),
              "error_counts": error_counts}
    (folder / "summary.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
    print("Comparisons:", comparisons, "Criterion met:", result["criterion_met"])


if __name__ == "__main__":
    for directory in sorted(OUTPUTS.glob("WS4-instruction-conflict*")):
        if directory.is_dir():
            pilot_result(directory / "pilot-T_s0.json")
            if (directory / "protocol.json").exists():
                final_result(directory)
