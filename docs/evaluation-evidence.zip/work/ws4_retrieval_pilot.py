"""WS4 development pilot on balanced code retrieval and explicit END supervision."""
import argparse
import random
from collections import Counter

from ws4_exploratory import (
    OUT, END, TEMPLATE, open_assets, load_target, prompt_ids, generate_batch,
    at_positions, atomic_json, torch, sha, RECORD, TOKENIZER,
)

TRAIN_NAMES = "London Paris Berlin Rome Tokyo Oslo Dublin Madrid Cairo Lagos Delhi Perth".split()
DEV_NAMES = "Athens Vienna Lima Seoul Boston Dallas Denver Miami".split()
TEST_NAMES = "Lisbon Prague Zurich Manila Austin Tampa Reno Phoenix".split()
DIFFICULTIES = (1, 2, 4)
CHECKS = (0, 16, 32, 64)


def make_cases(tok, names, pairs, seed, facts, alternate=False):
    rng = random.Random(seed)
    labels = [tok.encode(f" {digit}").ids for digit in range(1, 5)]
    assert all(len(ids) == 1 for ids in labels)
    rows = []
    for i in range(pairs):
        cities = rng.sample(names, facts)
        position = i % facts
        correct = i // facts % 4
        other = (correct + 1 + (i // (4 * facts)) % 3) % 4
        mapping = rng.sample([x for x in range(4) if x != correct], facts - 1)
        mapping.insert(position, correct)
        for flip in (False, True):
            values = mapping.copy()
            if flip:
                if other in values:
                    values[values.index(other)] = correct
                values[position] = other
            if alternate:
                context = "; ".join(f"{city}: {value+1}" for city, value in zip(cities, values))
                prompt = f"Codes: {context}. Give only the code assigned to {cities[position]}."
            else:
                context = " ".join(f"{city} has code {value+1}." for city, value in zip(cities, values))
                prompt = f"{context} What is the code for {cities[position]}? Reply with the code only."
            rows.append(dict(prompt=prompt, ids=prompt_ids(tok, prompt, TEMPLATE),
                             target=labels[values[position]][0], pair=i,
                             target_position=position))
    assert len(set(Counter(row["target"] for row in rows).values())) == 1
    return rows


def score(model, sets):
    results = {}
    model.eval()
    for key, rows in sets.items():
        outputs = []
        for offset in range(0, len(rows), 16):
            group = rows[offset:offset + 16]
            outputs.extend(generate_batch(model, [row["ids"] for row in group], 4, [END]))
        sequences = [entry["generated_ids"] for entry in outputs]
        first = [bool(seq) and seq[0] == row["target"] for seq, row in zip(sequences, rows)]
        exact = [seq == [row["target"], END] for seq, row in zip(sequences, rows)]
        results[key] = dict(
            n=len(rows), first_correct=sum(first), stopped=sum(END in seq for seq in sequences),
            exact_and_end=sum(exact), first_pairs=sum(a and b for a, b in zip(first[::2], first[1::2])),
            strict_pairs=sum(a and b for a, b in zip(exact[::2], exact[1::2])), outputs=outputs,
        )
    return results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--lr", type=float, required=True)
    parser.add_argument("--end-weight", type=float, default=1)
    parser.add_argument("--arm", choices="TDP", default="T")
    parser.add_argument("--seed", type=int, choices=(0, 1), default=0)
    parser.add_argument("--confirm", action="store_true")
    args = parser.parse_args()
    torch.set_num_threads(2)
    torch.use_deterministic_algorithms(True)
    record, tok = open_assets()
    model, digest, _ = load_target(record, f"{args.arm}_s{args.seed}", 0)
    train = {n: make_cases(tok, TRAIN_NAMES, 64, 1000+n, n) for n in DIFFICULTIES}
    names = TEST_NAMES if args.confirm else DEV_NAMES
    sets = {str(n): make_cases(tok, names, 16, 5000+n if args.confirm else 2000+n, n)
            for n in DIFFICULTIES}
    sets.update({f"{n}_rephrased": make_cases(tok, names, 16, 7000+n if args.confirm else 3000+n,
                                             n, alternate=True) for n in DIFFICULTIES})
    assert not set(TRAIN_NAMES) & set(names)
    out = dict(config=vars(args), checkpoint_sha256=digest, training_record_sha256=sha(RECORD),
               tokenizer_sha256=sha(TOKENIZER), script_sha256=sha(OUT.parent/"work/ws4_retrieval_pilot.py"),
               training_cases=train, evaluation_cases=sets, rows=[],
               schedule="16 steps at 1 fact, 16 steps mixing 1 and 2, then 32 steps mixing 2 and 4",
               accounting="16 applied response tokens per step, including repeated exposures and END")
    suffix = "confirm" if args.confirm else "dev"
    path = OUT / f"WS4-retrieval-pilot-{suffix}-{args.arm}{args.seed}-{args.lr:g}-end{args.end_weight:g}.json"
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, betas=(.9, .95), weight_decay=.1)
    weights = torch.tensor([1., args.end_weight])
    rng = random.Random(546)
    pools = {n: {label: [row for row in train[n] if row["target"] == label]
                 for label in sorted({row["target"] for row in train[n]})} for n in DIFFICULTIES}
    for step in range(CHECKS[-1]+1):
        if step in CHECKS:
            scores = score(model, sets)
            out["rows"].append(dict(step=step, applied_response_tokens=16*step, scores=scores))
            atomic_json(path, out)
            print(step, {k: (v["first_correct"], v["stopped"], v["strict_pairs"])
                         for k, v in scores.items()}, flush=True)
        if step == CHECKS[-1]:
            break
        model.train()
        difficulty = (1, 1) if step < 16 else (1, 2) if step < 32 else (2, 4)
        group = [rng.choice(pool) for n in difficulty for pool in pools[n].values()]
        rng.shuffle(group)
        logits = at_positions(model, [row["ids"] + [row["target"]] for row in group],
                              [[len(row["ids"])-1, len(row["ids"])] for row in group])
        y = torch.tensor([[row["target"], END] for row in group])
        loss = torch.nn.functional.cross_entropy(logits.flatten(0, 1), y.flatten(), reduction="none")
        loss = (loss.view(-1, 2) * weights).sum(dim=1).mean() / weights.sum()
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
        opt.step()
    out["complete"] = True
    atomic_json(path, out)


if __name__ == "__main__":
    main()
