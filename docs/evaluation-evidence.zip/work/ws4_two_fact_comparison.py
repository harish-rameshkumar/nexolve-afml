"""Freeze and run the WS4 matched two-fact architecture comparison."""
import argparse
import random
import re
from pathlib import Path

from ws4_retrieval_pilot import (
    CHECKS, DIFFICULTIES, TRAIN_NAMES, END, OUT, RECORD, TOKENIZER, TEMPLATE,
    at_positions, atomic_json, load_target, make_cases, open_assets, prompt_ids,
    score, sha, torch,
)
from evaluate_ws4_final import read

FOLDER = OUT / "WS4-two-fact-comparison"
PLAN = FOLDER / "protocol.json"
NAMES = "Jakarta Helsinki Tallinn Riga Naples Nice Kyoto Busan Quito Accra Bogota Warsaw".split()


def freeze(tok):
    assert not PLAN.exists(), "Protocol already frozen"
    training = {str(n): make_cases(tok, TRAIN_NAMES, 64, 1000+n, n) for n in DIFFICULTIES}
    standard = make_cases(tok, NAMES, 64, 8102, 2)
    alternate = make_cases(tok, NAMES, 64, 8102, 2, alternate=True)
    assert [r["target"] for r in standard] == [r["target"] for r in alternate]
    one_fact = []
    for row in standard:
        facts = re.findall(r"(\w+) has code ([1-4])\.", row["prompt"])
        city = re.search(r"What is the code for (\w+)\?", row["prompt"])[1]
        digit = dict(facts)[city]
        assert tok.encode(f" {digit}").ids == [row["target"]]
        prompt = f"{city} has code {digit}. What is the code for {city}? Reply with the code only."
        one_fact.append({**row, "prompt": prompt, "ids": prompt_ids(tok, prompt, TEMPLATE),
                         "target_position": 0})
    train_prompts = {r["prompt"] for rows in training.values() for r in rows}
    assert not train_prompts.intersection(r["prompt"] for r in standard + alternate + one_fact)
    assert not set(NAMES).intersection(TRAIN_NAMES)
    atomic_json(PLAN, {
        "question": "Does D learn counterfactual two-fact retrieval with fewer applied response tokens?",
        "primary": "Strict pair success (both answers exact code then END) on standard two-fact prompts. Normalized trapezoidal AUC from 0 to 1024 applied response tokens.",
        "criterion": "Evidence favoring D requires positive primary AUC differences versus both T and P in both paired seeds. Report all curves and contrasts regardless of sign.",
        "secondary": "Same facts in alternate wording, one-fact control without distractor, first-token pair correctness and stopping. Descriptive at two seeds.",
        "training": training, "evaluation": {"two_facts": standard, "two_facts_alternate": alternate,
                                             "one_fact_control": one_fact},
        "arms": ["T", "D", "P"], "seeds": [0, 1], "steps": list(CHECKS),
        "learning_rate": 2e-4, "end_weight": 1, "response_tokens_per_step": 16,
        "accounting": "All supervised answer and END tokens applied in FP32 updates, including repeated examples.",
        "recipe": "AdamW, betas .9/.95, weight decay .1, clipping 1. Pilot batch RNG 546; 16 one-fact steps, 16 one/two, 32 two/four.",
        "decoder": "greedy with END id 5 and four generated tokens maximum",
        "training_record_sha256": sha(RECORD), "tokenizer_sha256": sha(TOKENIZER),
        "script_sha256": sha(Path(__file__)),
    })


def train(arm, seed, threads):
    torch.set_num_threads(threads)
    torch.use_deterministic_algorithms(True)
    record, _ = open_assets()
    protocol = read(PLAN)
    for key, path in (("training_record", RECORD), ("tokenizer", TOKENIZER), ("script", Path(__file__))):
        assert protocol[f"{key}_sha256"] == sha(path), key
    name = f"{arm}_s{seed}"
    model, digest, actual = load_target(record, name, 0)
    assert actual == 0
    out = {"arm": arm, "seed": seed, "parent_sha256": digest, "protocol_sha256": sha(PLAN),
           "rows": [], "complete": False}
    path = FOLDER / f"{name}.json"
    opt = torch.optim.AdamW(model.parameters(), lr=protocol["learning_rate"],
                            betas=(.9, .95), weight_decay=.1)
    rng = random.Random(546)
    pools = {n: {label: [row for row in protocol["training"][str(n)] if row["target"] == label]
                 for label in sorted({row["target"] for row in protocol["training"][str(n)]})}
             for n in DIFFICULTIES}
    for step in range(CHECKS[-1]+1):
        if step in CHECKS:
            values = score(model, protocol["evaluation"])
            out["rows"].append({"step": step, "applied_response_tokens": 16*step, "scores": values})
            atomic_json(path, out)
            print(name, step, {k: (v["strict_pairs"], v["first_pairs"], v["stopped"])
                               for k, v in values.items()}, flush=True)
        if step == CHECKS[-1]:
            break
        model.train()
        difficulty = (1, 1) if step < 16 else (1, 2) if step < 32 else (2, 4)
        group = [rng.choice(pool) for n in difficulty for pool in pools[n].values()]
        rng.shuffle(group)
        logits = at_positions(model, [row["ids"] + [row["target"]] for row in group],
                              [[len(row["ids"])-1, len(row["ids"])] for row in group])
        y = torch.tensor([[row["target"], END] for row in group])
        loss = torch.nn.functional.cross_entropy(logits.flatten(0, 1), y.flatten())
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
        opt.step()
    out["complete"] = True
    atomic_json(path, out)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--freeze", action="store_true")
    parser.add_argument("--arm", choices="TDP")
    parser.add_argument("--seed", type=int, choices=(0, 1))
    parser.add_argument("--threads", type=int, default=2)
    args = parser.parse_args()
    if args.freeze:
        FOLDER.mkdir(parents=True, exist_ok=True)
        _, tokenizer = open_assets()
        freeze(tokenizer)
        print("Protocol SHA256", sha(PLAN), flush=True)
    elif args.arm is not None and args.seed is not None:
        train(args.arm, args.seed, args.threads)
    else:
        parser.error("use --freeze or specify --arm and --seed")


