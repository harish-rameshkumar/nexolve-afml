"""Train and test instruction following under conflicting demonstrations."""
import argparse
import random
from pathlib import Path

from ws4_retrieval_pilot import (
    OUT, END, TEMPLATE, RECORD, TOKENIZER, at_positions, atomic_json,
    load_target, open_assets, prompt_ids, score, sha, torch,
)
from evaluate_ws4_final import read

DIR = OUT / "WS4-instruction-conflict"
PROTOCOL = DIR / "protocol.json"
BUDGETS = (0, 8, 16, 32, 64, 96)
LABELS = (1, 2, 3, 4)


def cases(tok, count, seed, partition):
    rng = random.Random(seed)
    result = {key: [] for key in ("clean", "agree2", "conflict2", "agree6", "conflict6")}
    wordings = {
        "train": ("For the final item, return only {answer}.", "Output {answer} for the new item."),
        "dev": ("For the final item, return only {answer}.", "Output {answer} for the new item."),
        "final": ("Respond with {answer} for the final item.", "For the item being tested, write {answer} alone."),
    }
    words = {
        "train": ("map", "sun", "lamp", "cat", "tree", "cup", "stone", "rain", "lake", "pen"),
        "dev": ("goat", "moon", "bell", "dog", "mint", "ship", "snow", "desk", "hill", "book"),
        "final": ("bear", "star", "leaf", "fox", "sand", "boat", "wind", "door", "pond", "ring"),
    }[partition]
    target_ids = {i: tok.encode(f" {i}").ids for i in LABELS}
    assert all(len(ids) == 1 for ids in target_ids.values())
    for index in range(count):
        words_for_item = rng.sample(words, 7)
        foil = LABELS[index % 4]
        distance = 1 + (index // 4) % 3
        answers = [1 + (foil - 1 + (distance + j - 1) % 3 + 1) % 4 for j in (0, 1)]
        assert foil not in answers and len(set(answers)) == 2
        first = (index // 12) % 2 == 0
        wording = wordings[partition][(index // 24) % 2]
        for key, rows in result.items():
            n = 0 if key == "clean" else int(key[-1])
            for answer in answers:
                sample_output = answer if key.startswith("agree") else foil
                examples = [f"Example {w}: {sample_output}." for w in words_for_item[:n]]
                directive = wording.format(answer=answer)
                context = [directive, *examples] if first else [*examples, directive]
                prompt = " ".join([*context, f"Final item: {words_for_item[-1]}. Answer:"])
                rows.append({"pair": index, "ids": prompt_ids(tok, prompt, TEMPLATE),
                             "target": target_ids[answer][0], "foil": target_ids[foil][0],
                             "directive_first": first, "prompt": prompt})
    return result


def run(stage, arm, seed, strength, threads):
    torch.set_num_threads(threads)
    torch.use_deterministic_algorithms(True)
    record, tok = open_assets()
    training = cases(tok, 96, 7811, "train")
    if stage == "pilot":
        evaluation = cases(tok, 24, 7821, "dev")
        selected = evaluation
        protocol_digest = None
    else:
        protocol = read(PROTOCOL)
        assert protocol["script_sha256"] == sha(Path(__file__))
        assert protocol["tokenizer_sha256"] == sha(TOKENIZER)
        assert protocol["training_record_sha256"] == sha(RECORD)
        assert strength == protocol["strength"]
        protocol_digest = sha(PROTOCOL)
        selected = protocol["evaluation"]
        training = protocol["training"]
    train_prompts = {row["prompt"] for group in training.values() for row in group}
    assert not train_prompts.intersection(row["prompt"] for group in selected.values() for row in group)
    name = f"{arm}_s{seed}"
    model, parent, actual = load_target(record, name, 0)
    assert actual == 0
    out = {"stage": stage, "arm": arm, "seed": seed, "protocol_sha256": protocol_digest,
           "script_sha256": sha(Path(__file__)), "parent_sha256": parent, "rows": [], "complete": False}
    if stage == "pilot":
        out["evaluation"] = selected
    path = DIR / f"{stage}-{name}.json"
    opt = torch.optim.AdamW(model.parameters(), lr=2e-4, betas=(.9, .95), weight_decay=.1)
    rng = random.Random(7816)
    groups = tuple(training)
    for step in range(BUDGETS[-1]+1):
        if step in BUDGETS:
            scored = score(model, selected)
            for key, value in scored.items():
                value["foil_first"] = sum(g["generated_ids"][:1] == [row["foil"]]
                                          for g, row in zip(value["outputs"], selected[key]))
            out["rows"].append({"step": step, "tokens": step*16, "scores": scored})
            atomic_json(path, out)
            print(stage, name, step, {k: (v["strict_pairs"], v["stopped"], v["foil_first"])
                                      for k, v in scored.items()}, flush=True)
        if step == BUDGETS[-1]:
            break
        model.train()
        kinds = [*groups, "clean", "conflict2", "conflict6"]
        batch = [rng.choice(training[key]) for key in kinds]
        rng.shuffle(batch)
        logits = at_positions(model, [r["ids"] + [r["target"]] for r in batch],
                              [[len(r["ids"])-1, len(r["ids"])] for r in batch])
        y = torch.tensor([[r["target"], END] for r in batch])
        loss = torch.nn.functional.cross_entropy(logits.flatten(0, 1), y.flatten())
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
        opt.step()
    out["complete"] = True
    atomic_json(path, out)


def freeze():
    pilot = read(DIR / "pilot-T_s0.json")
    assert pilot["complete"] and not PROTOCOL.exists()
    threshold = .50
    # Require control competence and visible conflict cost at a checkpoint at
    # which the conflict task has been learned beyond the floor.
    qualified = []
    for n in (6, 2):
        for row in pilot["rows"]:
            s = row["scores"]
            c = s[f"conflict{n}"]["strict_pairs"] / 24
            a = s[f"agree{n}"]["strict_pairs"] / 24
            clean = s["clean"]["strict_pairs"] / 24
            if threshold <= c <= .85 and a-c >= .15 and clean >= .75:
                qualified.append(n)
                break
    if not qualified:
        print("Pilot gate failed. No architecture runs authorized by the protocol.")
        return
    n = qualified[0]
    _, tok = open_assets()
    evaluation = cases(tok, 48, 7831, "final")
    atomic_json(PROTOCOL, {"strength": n, "quality_target": threshold,
        "minimum_token_saving": .25, "minimum_conflict_cost_reduction": .10,
        "target_rule": "First evaluated budget at or above threshold, with all later budgets at or above threshold. If no checkpoint qualifies, report beyond max tested budget.",
        "success_rule": "D needs at least 25% fewer tokens than each control, in both seeds. For a control that never reaches target use the max budget as conservative bound. At first sustained target budget for D, D must have at least a 10 percentage point smaller agree-minus-conflict penalty than each control, in both seeds, and at least 75% on clean and agree, as must each control. Check clean/agree ceiling and alternate patterns before interpretation.",
        "score": "Both outputs in each pair must be the specified answer token followed by END. Greedy 4-token cap. Repeat examples are not unique tokens.",
        "note": "All arms see both strengths in training. Stronger condition chosen on T_s0 development, before final outputs.",
        "budgets": [s*16 for s in BUDGETS], "learning_rate": 2e-4,
        "tokenizer_sha256": sha(TOKENIZER), "training_record_sha256": sha(RECORD),
        "script_sha256": sha(Path(__file__)),
        "pilot_sha256": sha(DIR / "pilot-T_s0.json"),
        "training": cases(tok, 96, 7811, "train"),
        "evaluation": {k: evaluation[k] for k in ("clean", f"agree{n}", f"conflict{n}")}})
    print("Frozen", n, sha(PROTOCOL))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("pilot", "freeze", "final"))
    parser.add_argument("--arm", choices="TDP", default="T")
    parser.add_argument("--seed", type=int, choices=(0, 1), default=0)
    parser.add_argument("--threads", type=int, default=2)
    args = parser.parse_args()
    DIR.mkdir(exist_ok=True)
    if args.stage == "freeze":
        freeze()
    else:
        run(args.stage, args.arm, args.seed, read(PROTOCOL)["strength"] if args.stage == "final" else None, args.threads)
