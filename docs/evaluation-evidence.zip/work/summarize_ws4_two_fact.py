"""Recompute retrieval scores from frozen prompts and raw generated token IDs."""
from hashlib import sha256
import json
from pathlib import Path
import re
from statistics import mean

ROOT = Path(__file__).resolve().parents[1]
FOLDER = ROOT / "outputs/WS4-two-fact-comparison"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def recount(cases, outputs):
    assert len(cases) == len(outputs) == 128
    sequences = [g["generated_ids"] for g in outputs]
    first = [seq[:1] == [row["target"]] for seq, row in zip(sequences, cases)]
    exact = [seq == [row["target"], 5] for seq, row in zip(sequences, cases)]
    return {
        "n": len(cases), "first_correct": sum(first), "exact_and_end": sum(exact),
        "stopped": sum(5 in seq for seq in sequences),
        "first_pairs": sum(a and b for a, b in zip(first[::2], first[1::2])),
        "strict_pairs": sum(a and b for a, b in zip(exact[::2], exact[1::2])),
    }


def auc(tokens, scores):
    return sum((b-a)*(p+q)/2 for a, b, p, q in zip(tokens, tokens[1:], scores, scores[1:])) / (tokens[-1]*64)


def verify_prompts(evals):
    standard = evals["two_facts"]
    alternate = evals["two_facts_alternate"]
    single = evals["one_fact_control"]
    for base, variant, control in zip(standard, alternate, single, strict=True):
        facts = re.findall(r"(\w+) has code ([1-4])\.", base["prompt"])
        assert len(facts) == 2
        city = re.search(r"What is the code for (\w+)\?", base["prompt"])[1]
        assert re.findall(r"(\w+): ([1-4])", variant["prompt"]) == facts
        assert re.search(r"code assigned to (\w+)\.", variant["prompt"])[1] == city
        assert re.findall(r"(\w+) has code ([1-4])\.", control["prompt"]) == [(city, dict(facts)[city])]
        assert base["target"] == variant["target"] == control["target"]
    for rows in evals.values():
        assert all(a["pair"] == b["pair"] and a["target"] != b["target"]
                   for a, b in zip(rows[::2], rows[1::2]))


def main():
    path = FOLDER / "protocol.json"
    protocol = read(path)
    digest = sha256(path.read_bytes()).hexdigest()
    assert sha256((ROOT / "work/ws4_two_fact_comparison.py").read_bytes()).hexdigest() == protocol["script_sha256"]
    verify_prompts(protocol["evaluation"])
    tokens = [step*protocol["response_tokens_per_step"] for step in protocol["steps"]]
    results = {}
    parents = set()
    for seed in protocol["seeds"]:
        for arm in protocol["arms"]:
            name = f"{arm}_s{seed}"
            run = read(FOLDER / f"{name}.json")
            assert run["complete"] and run["protocol_sha256"] == digest
            assert run["arm"] == arm and run["seed"] == seed
            assert run["parent_sha256"] not in parents
            parents.add(run["parent_sha256"])
            assert [row["applied_response_tokens"] for row in run["rows"]] == tokens
            scores = {}
            for name_set, cases in protocol["evaluation"].items():
                rows = []
                for row in run["rows"]:
                    stored = row["scores"][name_set]
                    derived = recount(cases, stored["outputs"])
                    assert all(stored[key] == value for key, value in derived.items())
                    rows.append(derived)
                scores[name_set] = {"rows": rows,
                    "strict_auc": auc(tokens, [row["strict_pairs"] for row in rows])}
            results[name] = scores
    contrasts = {}
    for condition in protocol["evaluation"]:
        contrasts[condition] = {}
        for comparator in ("T", "P"):
            differences = [results[f"D_s{s}"][condition]["strict_auc"] -
                           results[f"{comparator}_s{s}"][condition]["strict_auc"] for s in protocol["seeds"]]
            contrasts[condition][f"D_minus_{comparator}"] = {"paired": differences, "mean": mean(differences)}
    criterion = all(value > 0 for c in contrasts["two_facts"].values() for value in c["paired"])
    summary = dict(protocol_sha256=digest, tokens=tokens, results=results,
                   contrasts=contrasts, criterion_met=criterion)
    (FOLDER / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    for name, result in results.items():
        print(name, {condition: ([r["strict_pairs"] for r in v["rows"]], round(v["strict_auc"], 5))
                     for condition, v in result.items()})
    print("Contrasts", contrasts)
    print("Criterion met:", criterion)


if __name__ == "__main__":
    main()
