Evaluation evidence for the paper

Extract the archive, open a terminal in the extracted folder, and run with Python 3.12:

python work/summarize_ws4_two_fact.py
python work/summarize_ws4_instruction_conflict.py
python work/summarize_ws4_conflict_transfer.py

These commands recalculate results from frozen prompts and saved model predictions without training data or weights. The original experiment scripts are retained for provenance and use the original workspace layout.
